$module = Get-InstalledModule -Name ActiveDirectory -ErrorAction SilentlyContinue | Select Name -ExpandProperty Name
if ($module -eq $NULL) {
    $module = Get-Module -Name ActiveDirectory -ErrorAction SilentlyContinue | Select Name -ExpandProperty Name
    if ($module -eq $NULL) {
        Install-Module ActiveDirectory
    }
}

# Import PSWindowsUpdate module
Import-Module ActiveDirectory

$DateTime = Get-Date -Format "DD_HH_mm"
$LogName = "Initial_ADSetup_" + $DateTime + ".txt"

Start-Transcript -LiteralPath ("C:\Windows\Temp\" + $LogName)

$ADUsers = Get-ADUser -Filter * -Properties Enabled, Description, MemberOf | Where-Object {$_.Description -notmatch "Scoring User"} | Select SamAccountName, Enabled, MemberOf
$LocalUsers = Get-LocalUser -ErrorAction SilentyContinue | Select Name, PrincipalSource, Enabled | Where-Object PrincipalSource -eq "Local"

Write-Host "Creating CCDC user"
New-ADUser -Name 'ccdc' -SamAccountName ccdc -Verbose
Add-ADGroupMember -Identity 'Administrators' -Members ccdc -Verbose
Add-ADGroupMember -Identity 'Domain Admins' -Members ccdc -Verbose
Add-ADGroupMember -Identity 'Enterprise Admins' -Members ccdc -Verbose
Add-ADGroupMember -Identity 'Group Policy Creator Owners' -Members ccdc -Verbose
Add-ADGroupMember -Identity 'Schema Admins' -Members ccdc -Verbose
Add-ADGroupMember -Identity 'DnsAdmins' -Member ccdc -Verbose
Set-ADUser -Identity ccdc -Enabled $True -ChangePasswordAtLogon $True -PasswordNotRequired $True -Verbose

Write-Host "AUDITING USERS ------ AD USERS" -BackgroundColor Cyan
if ($ADUsers -ne $NULL) {
    $ADUsers | FT
}
else {
    Write-Host ("No Active Directory Accounts found!")
}

Write-Host "`n`nAUDITING USERS ----- LOCAL USERS NOT IN AD" -BackgroundColor Cyan
if ($LocalUsers -ne $NULL) {
    foreach ($User in $LocalUsers.Name){
        Write-Host ($User + " IS A LOCAL ACCOUNT") -ForegroundColor Red -BackgroundColor Yellow   
    }
}
else {
    Write-Host ("No local accounts found!")
}

Write-Host "`n`nAUDITING ADMIN GROUP MEMBERSHIPS -----"
foreach ($User in $ADUsers) {
    Write-Host ("Memberships for: " + $User.SamAccountName)
    $groups = Get-ADPrincipalGroupMembership $User.SamAccountName | Select -ExpandProperty Name
    foreach ($group in $groups) { Write-Host (" " + $group) }
    Write-Host ("")
}

Write-Host "`n`nAUDITING FOREIGN SECURITY PRINCIPALS -----"
Get-ADObject -Filter { ObjectClass -eq "foreignSecurityPrincipal" }


$CurrentUser = Get-ADUser -Identity krbtgt
Add-Type -AssemblyName System.Web
$Password = [System.Web.Security.Membership]::GeneratePassword(100, 20)
$Password = ConvertTo-SecureString -String $Password -AsPlainText -Force
Set-ADAccountPassword -NewPassword $Password -Verbose -Identity $CurrentUser

$Password = [System.Web.Security.Membership]::GeneratePassword(100, 20)
$Password = ConvertTo-SecureString -String $Password -AsPlainText -Force
$CurrentUser = Get-ADUser -Identity Guest
Set-ADAccountPassword -NewPassword $Password -Verbose -Identity $CurrentUser

#Get-Service * | Select DisplayName, Status | Sort Status,DisplayName -Descending
#$Running = Get-Service * | Where Status -eq "Stopped" | Measure | Select Count
#Write-Host ("There are " + $Running + " running services") -ForegroundColor Yellow
#$Stopped = Get-Service * | Where Status -eq "Running" | Measure | Select Count
#Write-Host ("There are " + $Stopped + " stopped services") -ForegroundColor Yellow

Stop-Service -Name NetBIOS -Verbose
Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object {$_.IPEnabled -eq $true} | Invoke-WmiMethod -Name SetTcpipNetbios -ArgumentList 2 -Verbose

Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol

# THIS WILL REBOOT THE COMPUTER
#Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol

#Write-Host("Listening Ports")
#Get-NetTCPConnection -State Listen

#Write-Host ("Established Ports")
#Get-NetTCPConnection -State Established

#Write-Host ("Port Status with Process Names")
#Get-NetTCPConnection | Select-Object -Property LocalAddress,LocalPort,RempteAddress,RemotePort,State, @{'Name' = 'ProcessName';'Expression'={(Get-Process -Id $_.OwningProcess).Name}} | Sort State,LocalAddress,LocalPort | Format-Table

Write-Host "Configuring Password Policy"
Get-ADDefaultDomainPasswordPolicy
Set-ADDefaultDomainPasswordPolicy -MinPasswordLength 15 -LockoutThreshold 4 -Verbose

Write-Host "Configuring DNS Settings"
Get-DNSServerDiagnostics
New-Item -Path "C:\" -Name Logging -ItemType "directory"
Set-DNSServerDiagnostics -All $true -Verbose
Set-DnsServerDiagnostics -LogFilePath "C:\Logging\DNS-Log.txt" -Verbose

Write-Host ("Auditing DNS Caches")
Get-DnsClientCache
Get-DnsServerCache | Select *

Get-Content -LiteralPath "C:\Windows\System32\drivers\etc\hosts"

#Scan event logs for logs relating to specific users  
#Set up NTP pointing to the correct machine
#Configure rsyslog to send logs to Splunk

# Install Wireshark
$ProgressPreference = 'SilentlyContinue'
$Uri = https://2.na.dl.wireshark.org/win64/Wireshark-4.4.3-x64.exe
Invoke-WebRequest -URI $Uri -Outfile wireshark_installer.exe
$ProgressPreference = 'Continue'
.\wireshark_installer.exe

Stop-Transcript
