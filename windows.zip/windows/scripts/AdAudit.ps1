$module = Get-InstalledModule -Name ActiveDirectory -ErrorAction SilentlyContinue | Select Name -ExpandProperty Name
if ($module -eq $NULL) {
    $module = Get-Module -Name ActiveDirectory -ErrorAction SilentlyContinue | Select Name -ExpandProperty Name
    if ($module -eq $NULL) {
        Install-Module ActiveDirectory
    }
}
 
Import-Module "ActiveDirectory"

$DateTime = Get-Date -Format "DD_HH_mm"
$LogName = "AD_Audit_" + $DateTime + ".txt"

Start-Transcript -LiteralPath ("C:\Windows\Temp\" + $LogName)

$ADUsers = Get-ADUser -Filter * -Properties Enabled, Description, MemberOf | Where-Object {$_.Description -notmatch "Scoring User"} | Select SamAccountName, Enabled, MemberOf
$LocalUsers = Get-LocalUser -ErrorAction SilentyContinue | Select Name, PrincipalSource, Enabled | Where-Object PrincipalSource -eq "Local"

Write-Host "AUDITING USERS ------ AD USERS" -BackgroundColor Cyan
if ($ADUsers -ne $NULL) {
    $ADUsers | FT
}
else {
    Write-Host ("No Active Directory Accounts found!")
}

Write-Host "`n`nAUDITING USERS ----- LOCAL USERS NOT IN AD" -BackgroundColor Cyan
if ($LocalUsers -ne $NULL) {
    foreach ($User in $LocalUsers.Name){
        Write-Host ($User + " IS A LOCAL ACCOUNT") -ForegroundColor Red -BackgroundColor Yellow   
    }
}
else {
    Write-Host ("No local accounts found!")
}

Write-Host "`n`nAUDITING ADMIN GROUP MEMBERSHIPS -----"
foreach ($User in $ADUsers) {
    Write-Host ("Memberships for: " + $User.SamAccountName)
    $groups = Get-ADPrincipalGroupMembership $User.SamAccountName | Select -ExpandProperty Name
    foreach ($group in $groups) { Write-Host (" " + $group) }
    Write-Host ("")
}

Write-Host "`n`nAUDITING FOREIGN SECURITY PRINCIPALS -----"
Get-ADObject -Filter { ObjectClass -eq "foreignSecurityPrincipal" }

Write-Host "`n`nAUDITING SMB FILE SHARES -----"
Get-SMBShare | Select-Object Name, Path, Description, Permissions

$CurrentUser = Get-ADUser -Identity krbtgt
Add-Type -AssemblyName System.Web
$Password = [System.Web.Security.Membership]::GeneratePassword(100, 20)
$Password = ConvertTo-SecureString -String $Password -AsPlainText -Force
Set-ADAccountPassword -NewPassword $Password -Verbose -Identity $CurrentUser

$Password = [System.Web.Security.Membership]::GeneratePassword(100, 20)
$Password = ConvertTo-SecureString -String $Password -AsPlainText -Force
$CurrentUser = Get-ADUser -Identity Guest
Set-ADAccountPassword -NewPassword $Password -Verbose -Identity $CurrentUser

#Get-Service * | Select DisplayName, Status | Sort Status,DisplayName -Descending
#$Running = Get-Service * | Where Status -eq "Stopped" | Measure | Select Count
#Write-Host ("There are " + $Running + " running services") -ForegroundColor Yellow
#$Stopped = Get-Service * | Where Status -eq "Running" | Measure | Select Count
#Write-Host ("There are " + $Stopped + " stopped services") -ForegroundColor Yellow

# Audit services not under the windows directory, essentially non-"default" services
# Thank you: https://powershelladministrator.com/2014/04/28/get-all-non-default-windows-services/
$NonDefaultServices = Get-wmiobject win32_service | where { $_.Caption -notmatch "Windows" -and $_.PathName -notmatch "Windows" -and $_.PathName -notmatch "policyhost.exe" -and $_.Name -ne "LSM" -and $_.PathName -notmatch "OSE.EXE" -and $_.PathName -notmatch "OSPPSVC.EXE" -and $_.PathName -notmatch "Microsoft Security Client" }

Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol

Write-Host("Listening Ports")
Get-NetTCPConnection -State Listen

Write-Host ("Established Ports")
Get-NetTCPConnection -State Established

Write-Host ("Port Status with Process Names")
Get-NetTCPConnection | Select-Object -Property LocalAddress,LocalPort,RempteAddress,RemotePort,State, @{'Name' = 'ProcessName';'Expression'={(Get-Process -Id $_.OwningProcess).Name}} | Sort State,LocalAddress,LocalPort | Format-Table

Write-Host "Configuring Password Policy"
Get-ADDefaultDomainPasswordPolicy

Write-Host "Configuring DNS Settings"
Get-DNSServerDiagnostics

Write-Host ("Auditing DNS Caches")
Get-DnsClientCache
Get-DnsServerCache 

Get-Content -LiteralPath "C:\Windows\System32\drivers\etc\hosts"

Stop-Transcript
